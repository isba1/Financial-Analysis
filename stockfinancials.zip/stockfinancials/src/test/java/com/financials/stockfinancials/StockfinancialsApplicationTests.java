package com.financials.stockfinancials;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockfinancialsApplicationTests {

	@Test
	void contextLoads() {
	}

}
