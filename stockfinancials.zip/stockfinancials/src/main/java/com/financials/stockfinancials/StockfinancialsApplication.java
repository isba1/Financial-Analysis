package com.financials.stockfinancials;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockfinancialsApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockfinancialsApplication.class, args);
	}

}
